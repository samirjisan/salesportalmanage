<style>

    footer {
        position: fixed;
        left: 0;
        bottom: 0;
        width: 100%;
        text-align: center;
        padding: 3px;
        background-color: Black;
        color: white;
    }

</style>

<footer>A Brand of Race Online LTD</footer>