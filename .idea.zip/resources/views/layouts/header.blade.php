<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    {{--<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">--}}
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    {{--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">--}}
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>

{{--element {--}}
{{--}--}}
{{--.topnav .w3-bar a.active {--}}
{{--background-color: #04AA6D !important;--}}
{{--color: #ffffff;--}}
{{--}--}}
{{--.w3-bar .w3-button {--}}
{{--white-space: normal;--}}
{{--}--}}
{{--.w3-bar .w3-bar-item {--}}
{{--padding: 8px 16px;--}}
{{--float: left;--}}
{{--width: auto;--}}
{{--border: none;--}}
{{--display: block;--}}
{{--outline: 0;--}}
{{--}--}}
{{--.w3-bar a, .w3-button, .w3-btn {--}}
{{--text-decoration: none !important;--}}
{{--}--}}
{{--.topnav a {--}}
{{--padding: 10px 15px 9px 15px !important;--}}
{{--}--}}
{{--.w3-btn, .w3-button {--}}
{{---webkit-touch-callout: none;--}}
{{---webkit-user-select: none;--}}
{{---khtml-user-select: none;--}}
{{---moz-user-select: none;--}}
{{---ms-user-select: none;--}}
{{--user-select: none;--}}
{{--}--}}
{{--.w3-btn, .w3-button {--}}
{{--border: none;--}}
{{--display: inline-block;--}}
{{--padding: 8px 16px;--}}
{{--vertical-align: middle;--}}
{{--overflow: hidden;--}}
{{--text-decoration: none;--}}
{{--color: inherit;--}}
{{--background-color: inherit;--}}
{{--text-align: center;--}}
{{--cursor: pointer;--}}
{{--white-space: nowrap;--}}
{{--}--}}
{{--a {--}}
{{--text-decoration: underline;--}}
{{--}--}}
{{--a {--}}
{{--color: inherit;--}}
{{--}--}}
{{--a {--}}
{{--background-color: transparent;--}}
{{--}--}}
{{--a {--}}
{{--color: #337ab7;--}}
{{--text-decoration: none;--}}
{{--}--}}
{{--a {--}}
{{--background-color: transparent;--}}
{{--}--}}
{{--*, ::before, ::after {--}}
{{--box-sizing: inherit;--}}
{{--}--}}
{{--* {--}}
{{---webkit-box-sizing: border-box;--}}
{{---moz-box-sizing: border-box;--}}
{{--box-sizing: border-box;--}}
{{--}--}}
{{--.topnav {--}}
{{--font-size: 17px;--}}
{{--color: #f1f1f1;--}}
{{--letter-spacing: 1px;--}}
{{--font-family: 'Source Sans Pro', sans-serif;--}}
{{--}--}}
{{--html, body {--}}
{{--font-family: Verdana,sans-serif;--}}
{{--font-size: 15px;--}}
{{--line-height: 1.5;--}}
{{--}--}}
{{--body {--}}
{{--font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;--}}
{{--font-size: 14px;--}}
{{--line-height: 1.42857143;--}}
{{--color: #333;--}}
{{--}--}}
{{--html {--}}
{{--font-size: 10px;--}}
{{--}--}}
{{--html {--}}
{{--font-family: sans-serif;--}}
{{---webkit-text-size-adjust: 100%;--}}
{{--}--}}