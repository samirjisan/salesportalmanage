<style>
body{
background-image: url("/image/bcg.jpg");
background-repeat: no-repeat;
background-size: cover;
}

.btnRegister {
    background-color: darkorchid;
    border: none;
    color: black;
    padding: 5px 25px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
    border-radius: 5px;
}

.btnRegister:hover {
    background-color: #4CAF50;
    color: white;
}

.btnRegister1 {
    background-color: blueviolet;
    border: none;
    color: black;
    padding: 5px 20px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
    border-radius: 5px;
}

.btnRegister2 {
    background-color: rosybrown;
    border: none;
    color: black;
    padding: 5px 20px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
    border-radius: 5px;
}

.btnRegister1:hover {
    background-color: #4CAF50;
    color: white;
}

.btnRegister2:hover {
    background-color: red;
    color: white;
}
</style>