<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSalesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('sales', function (Blueprint $table) {

            $table->bigIncrements('Count');
            $table->date('Create');
            $table->string('ZONE');
            $table->string('TEAM');
            $table->string('EMPLOYEE');
            $table->string('Subscriber_ID');
            $table->string('Offer');
            $table->string('Package');
            $table->string('MRC');
            $table->string('OTC');
            $table->string('Advance');
            $table->string('Total');
            $table->date('Delivery');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('sales');
    }
}
