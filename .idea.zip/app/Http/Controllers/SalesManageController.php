<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;

use App\Sale;
use App\User;
use Illuminate\Http\Request;
use App\Exports\SaleExport;
use Excel;

class SalesManageController extends Controller
{
    public function index()
    {
        $sales = Sale::latest()->paginate(7);
//        $sales = User::find(Auth::id())->sales()->paginate(2);
        return view('sales.showSales', compact(['sales']));
    }

    public function edit($Count)
    {
//        $sale = Sale::find($Count);
//        return view('sales.edit',compact('sale'));


        $sale = Sale::where('Count', $Count)->first();
        return view('sales.edit', compact('sale'));

    }

    public function update($Count)
    {
        //  $sale = Sale::find($Count);
        $sale = Sale::where('Count', $Count);
        $sale->update([
            'Create' => request('Create'),
            'ZONE' => request('ZONE'),
            'TEAM' => request('TEAM'),
            'EMPLOYEE' => request('EMPLOYEE'),
            'Subscriber_ID' => request('Subscriber_ID'),
            'Offer' => request('Offer'),
            'Package' => request('Package'),
            'MRC' => request('MRC'),
            'OTC' => request('OTC'),
            'Advance' => request('Advance'),
            'Total' => request('Total'),
            'Delivery' => request('Delivery')
        ]);

        return redirect()->route('sales.show')->with('updateSuccess', 'Update Successfully!');


    }

    public function delete($Count)
    {
        Sale::where('Count', $Count)->delete();
        return redirect()->route('sales.show')->with('deleteSuccess', 'Deleted Successfully!');
    }

    public function exportIntoExcel()
    {
        return Excel::download(new SaleExport, 'salelist.xlsx');
    }

//    public function search(Request $request)
//    {
//        // Get the search value from the request
//        $search = $request->input('search');
//
//        // Search in the title and body columns from the posts table
//        $sales = Sale::query()
//            ->where('title', 'LIKE', "%{$search}%")
//            ->orWhere('body', 'LIKE', "%{$search}%")
//            ->get();
//
//        // Return the search view with the results compacted
//        return view('sales.search', compact('sales'));
//    }

    public function search()
    {
        $search_text =$_GET['query'];
        $sale = Sale::where('title','LIKE','%'.$search_text.'%')->get();

        return view('sales.search',compact('sale'));
    }
}
