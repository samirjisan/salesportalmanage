<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserManageController extends Controller
{
    //
}
