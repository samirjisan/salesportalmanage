<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Sale extends Model
{
    protected $table = 'sales';
    protected $fillable = ['Create', 'ZONE', 'TEAM', 'EMPLOYEE', 'Subscriber_ID', 'Offer', 'Package', 'MRC', 'OTC', 'Advance', 'Total', 'Delivery'];
    protected $primarykey = 'Count';

    public static function  getSale()
    {
        $records = DB::table('sales')->select('Create', 'ZONE', 'TEAM', 'EMPLOYEE', 'Subscriber_ID', 'Offer', 'Package', 'MRC', 'OTC', 'Advance', 'Total', 'Delivery')->get()->toArray();
        return $records;
    }

//    public function sales(){
//
//        return $this->hasMany(Sale::class);
//    }
}
