<?php

namespace App\Exports;

use App\Sale;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class SaleExport implements FromCollection,WithHeadings
{

    public function headings(): array
    {
        return [
            'ID',
            'Create',
            'ZONE',
            'TEAM',
            'EMPLOYEE',
            'Subscriber_ID',
            'Offer',
            'Package',
            'MRC', 'OTC',
            'Advance',
            'Total',
            'Delivery',
            'create_at',
            'update_at'
        ];
    }
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
       return Sale::all();
        //return $this->collection(Sale::getSale());
    }
}
