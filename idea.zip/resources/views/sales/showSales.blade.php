<html>

<head>

    <title>Show Users</title>

    @include('layouts.header')

    <style>
        table {
            width:100%;
        }
        table, th, td {
            border: 2px solid black;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        /*#td tr:nth-child(even) {*/
            /*background-color: blue;*/
        /*}*/
        /*#td tr:nth-child(odd) {*/
            /*background-color: greenyellow;*/
        /*}*/
        th {
            background-color: olive;
            color: white;
        }
        h1 {
            color: blueviolet;
            text-align: center;
            /*border: 3px solid green;*/

        }




    </style>
</head>

<body>
@include('layouts.body')


<nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="#">ORBIT</a>
        </div>
        <ul class="nav navbar-nav">
            <li><a href="{{ route('sales.list') }}"><span class="glyphicon glyphicon-Add New User"></span> Add New User</a></li>
            <li><a href="{{ route('sales.show') }}"><span class="glyphicon glyphicon-Show All Entries"></span>Show All Entries</a></li>
            <li><a href="{{ route('sales.exportIntoExcel') }}"><span class="glyphicon glyphicon-Report"></span> Download Report</a></li>
            {{--<li><a href="{{ route('sales.exportIntoExcel') }}"><input type="submit" name="submit" value="Report"></a></li>--}}
            {{--<li><a href="#"><span class="glyphicon glyphicon-Add New User"></span> Login</a></li>--}}
        </ul>
        <ul class="nav navbar-nav navbar-right">
            <li><a href="{{ route('user.logout') }}">( {{ App\User::find(Auth::id())->username }} )<span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
            {{--<li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>--}}
        </ul>

        <form class="navbar-form navbar-left" action="{{route('sales.show')}}">
            <div class="input-group">
                <input type="text" class="form-control" placeholder="Search" name="search">
                <div class="input-group-btn">
                    <button class="btn btn-default" type="submit">
                        <i class="glyphicon glyphicon-search"></i>
                    </button>
                    </div>
            </div>
        </form>
    </div>
</nav>


@if(session('updateSuccess'))
<p style="color:green;">{{ session('updateSuccess') }}</p>
@endif

@if(session('deleteSuccess'))
    <p style="color:red;">{{ session('deleteSuccess') }}</p>
@endif


@if(session('addSuccess'))
    <p style="color:blue;">{{ session('addSuccess') }}</p>
@endif
<h1>Show All Sales</h1>
<table border="2px">
    <tr style="color: #000088">
        {{--<th>Count</th>--}}
        <th>Create Date</th>
        <th>Zone</th>
        <th>Team</th>
        <th>Employee</th>
        <th>Subscriber ID</th>
        <th>Offer</th>
        <th>Package</th>
        <th>MRC</th>
        <th>OTC</th>
        <th>Advance</th>
        <th>Total</th>
        <th>Payment Date</th>
    </tr>
    @foreach($sales as $sale)
    <tr>
        <td>{{ $sale->Create }}</td>
        <td>{{ $sale->ZONE}}</td>
        <td>{{ $sale->TEAM }}</td>
        <td>{{ $sale->EMPLOYEE }}</td>
        <td>{{ $sale->Subscriber_ID }}</td>
        <td>{{ $sale->Offer }}</td>
        <td>{{ $sale->Package }}</td>
        <td>{{ $sale->MRC }}</td>
        <td>{{ $sale->OTC }}</td>
        <td>{{ $sale->Advance }}</td>
        <td>{{ $sale->Total }}</td>
        <td>{{ $sale->Delivery }}</td>

        {{--<td><a href="{{ route('sales.edit',[$sale->Count]) }}" title="edit" class="edit" onclick="return confirm('Are you sure you want to edit this item')">Edit</a>||<a href="{{ route('sales.delete',[$sale->Count]) }}"title="delete" class="delete" onclick="return confirm('Are you sure you want to delete this item')">Delete</a></td>--}}
    </tr>
    @endforeach
</table>

<span>
    {{$sales->links()}}
</span>

{{--<a href="{{ route('sales.list') }}"><input type="submit" style="background: blueviolet; color: black" name="submit" value="Add New User"></a>--}}
{{--<a href="{{ route('user.see') }}"><input type="submit" style="background: blueviolet; color: black" name="submit" value="Show All Users"></a>--}}
{{--<a href="{{ route('sales.exportIntoExcel') }}"><input type="submit" style="background: blueviolet; color: black" name="submit" value="Report"></a>--}}
{{--<input type="submit" name="submit" value="Add New User">--}}
@include('layouts.footer')
</body>

</html>
