<html>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<title>EDIT SALES</title>
<body>
@include('layouts.body')


<style>

    h2  {
        text-align: center;
    }
</style>

<div class="col-md-6">
    <h2 style="color: #b854d4">Edit User</h2>
</div>
<div class="col-md-12">
    <img src="/image/Capture.JPG" alt="Orbit" class="float-right" width="300" height="200">
</div>

<div class="col-md-12">
    <a href="{{ route('user.logout') }}" class="float-right">( {{ App\User::find(Auth::id())->username }} )Logout</a>
</div>


    {{--<h1>User</h1>--}}
    {{--<a href="{{ route('user.logout') }}">( {{ App\User::find(Auth::id())->username }} )Logout</a>--}}


    <form action="{{route('sales.update',[$sale->Count])}}" method="post" enctype="multipart/form-data">
        {{csrf_field()}}


        <div class="container register">
            <div class="row">

                <div class="col-md-9 register-right">

                    {{--<div class="tab-content" id="myTabContent">--}}
                    {{--<div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">--}}

                    <div class="row register-form">
                        <div class="col-md-3">
                            <div class="form-group">
        <p>Create<input type="date" name="Create" class="form-control" placeholder="Create" value="{{ $sale->Create }}"></p>
                            </div>
                            <div class="form-group">
        <p>Zone<input type="text" name="ZONE" class="form-control" placeholder="Zone" value="{{ $sale->ZONE }}"></p>
                                </div>
                            <div class="form-group">
        <p>Team<input type="text" name="TEAM" class="form-control" placeholder="Team" value="{{ $sale->TEAM }}"></p>
                                </div>
                            <div class="form-group">
        <p>EMPLOYEE<input type="text" name="EMPLOYEE" class="form-control" placeholder="Employee" value="{{ $sale->EMPLOYEE }}"></p>
                                </div>
                            <div class="form-group">
        <p>Subscriber_ID<input type="text" name="Subscriber_ID" class="form-control" placeholder="Subscriber_ID" value="{{ $sale->Subscriber_ID }}"></p>
                                </div>
                            <div class="form-group">
        <p>Offer<input type="text" name="Offer" class="form-control" placeholder="Offer" value="{{ $sale->Offer }}"></p>

                            </div>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group">
        <p>Package<input type="text" name="Package" class="form-control" placeholder="Package" value="{{ $sale->Package }}"></p>
                                    </div>
                                <div class="form-group">
        <p>MRC<input type="text" name="MRC" class="form-control" placeholder="MRC" value="{{ $sale->MRC }}"></p>
                                    </div>
        <p>OTC<input type="text" name="OTC" class="form-control" placeholder="OTC" value="{{ $sale->OTC }}"></p>
                                <div class="form-group">
                                    </div>
                                <div class="form-group">
        <p>Advance<input type="text" name="Advance" class="form-control" placeholder="Advance" value="{{ $sale->Advance }}"></p>
                                    </div>
                                <div class="form-group">
        <p>Total<input type="text" name="Total" class="form-control" placeholder="Total" value="{{ $sale->Total }}"></p>
                                    </div>
                                <div class="form-group">
        <p>Delivery<input type="DATE" name="Delivery" class="form-control" placeholder="Delivery Date" value="{{ $sale->Delivery }}"></p>
                                    </div>
                                <input type="submit" class="btnRegister"  value="Update"/>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

    </form>

@include('layouts.footer')

</body>
{{--@endsection--}}
</html>