<html>

<head>

    <title>Enter New Sale</title>

    @include('layouts.header')

    <style>
        table {
            width:100%;
        }
        table, th, td {
            border: 2px solid black;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: olive;
            color: white;
        }
        h1 {
            color: blueviolet;
            text-align: center;
            /*border: 3px solid green;*/
            text-decoration: underline;
            padding: 00px 800px 10px 80px;
            /*/!*padding-top: 50px;*!/*/
            /*padding-right: 800px;*/
            /*padding-bottom: 50px;*/
            /*padding-left: 80px;*/
        }


    </style>
</head>

<body>

@include('layouts.body')

<nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="#">ORBIT</a>
        </div>
        <ul class="nav navbar-nav">
            <li><a href="{{ route('sales.list') }}"><span class="glyphicon glyphicon-Add New User"></span> Add New User</a></li>
            <li><a href="{{ route('sales.show') }}"><span class="glyphicon glyphicon-Show All Entries"></span>Show All Entries</a></li>
            <li><a href="{{ route('sales.exportIntoExcel') }}"><span class="glyphicon glyphicon-Report"></span> Download Report</a></li>
        </ul>
        <ul class="nav navbar-nav navbar-right">
            <li><a href="{{ route('user.logout') }}">( {{ App\User::find(Auth::id())->username }} )<span class="glyphicon glyphicon-log-out"></span> Logout</a></li>

        </ul>

    </div>
</nav>


<h1>Enter New Sale</h1>
@include('errors.error')
<form action="{{route('sales.list')}}" method="POST" enctype="multipart/form-data">

    {{csrf_field()}}

    <div class="container register">
        <div class="row">

            <div class="col-md-9 register-right">


                <div class="row register-form">
                    <div class="col-md-3">
                        <div class="form-group">
                            <!--                                <label for="exampleInputDate">Create Date</label>-->
                            <p>Create Date<input type="date" class="form-control" name="Create"  placeholder="Create"></p>
                        </div>


                            <div class="form-group">
                                <p>Select Zone<select class="form-control" name="ZONE">
                                        <option >Select Zone</option>
                                        <!-- <option>Select</option>-->
                                        <option>Banani</option>
                                        <option>Basundhara</option>
                                        <option>Dhanmondi</option>
                                        <option>Motijhil</option>
                                        <option>Uttara</option>
                                        <option>Chittagong</option>
                                        <option>Cox's Bazar</option>
                                        <option>Khulna</option>
                                        <option>Sylhet</option>

                                    </select></p>
                            </div>

                        <div class="form-group">
                            <p>Select Zone<select class="form-control" name="TEAM">
                                    <option >Select Team</option>
                                    <!-- <option>Select</option>-->
                                    <option>Direct Sales</option>
                                    <option>Tele Sales</option>
                                </select></p>
                        </div>
                        <div class="form-group">
                            <!--                                <label for="exampleInputZone">Employee</label><br>-->
                            <p>Employee<input type="text" class="form-control" name="EMPLOYEE" placeholder="Employee"></p>
                        </div>

                        <div class="form-group">
                            <!--                                <label for="exampleInputZone">Subscriber ID</label><br>-->
                            <p>Subscriber_ID<input type="text" class="form-control" name="Subscriber_ID" placeholder="Subscriber_ID"></p>
                        </div>
                        <div class="form-group">
                            <!--                                <label for="exampleInputZone">Offer</label><br>-->
                            <p>Offer<input type="text" class="form-control" name="Offer" placeholder="Offer"></p>
                        </div>

                    </div>
                    <div class="col-md-3">

                        <div class="form-group">
                            <p>Select Package<select class="form-control" name="Package">
                                    <option >Select Package</option>
                                    <option>10 MBPS</option>
                                    <option>15 MBPS</option>
                                    <option>25 MBPS</option>
                                    <option>30 MBPS</option>
                                    <option>35 MBPS</option>
                                    <option>40 MBPS</option>
                                    <option>45 MBPS</option>
                                    <option>50 MBPS</option>
                                    <option>75 MBPS</option>

                                </select></p>
                        </div>

                        <div class="form-group">
                            <!--                                <label for="exampleInputZone">MRC</label><br>-->
                            <p>MRC<input type="text" class="form-control" name="MRC" placeholder="MRC"></p>
                        </div>
                        <div class="form-group">
                            <!--                                <label for="exampleInputZone">OTC</label><br>-->
                            <p>OTC<input type="text" class="form-control" name="OTC" placeholder="OTC"></p>
                        </div>
                        <div class="form-group">
                            <!--                                <label for="exampleInputZone">Advance(Months</label><br>-->
                            <p>Advance(Months)<input type="text" class="form-control" name="Advance" placeholder="Advance(Months)"></p>
                        </div>
                        <div class="form-group">
                            <!--                                <label for="exampleInputZone">Total</label><br>-->
                            <p>Total<input type="text" class="form-control" name="Total" placeholder="Total" onmouseup="calcTotal()"></p>
                        </div>
                        <div class="form-group">
                            <!--                                <label for="exampleInputDate">Delivery Date</label><br>-->
                            <p>Payment Date<input type="date" class="form-control" name="Delivery" aria-describedby="dateHelp" placeholder="Payment Date"></p>
                        </div>
                        <input type="submit" class="btnRegister"  value="Save"/>
                    </div>
                </div>

            </div>
        </div>

    </div>


</form>

<script>
    function calcTotal() {
        let MRC = document.getElementsByName("MRC")[0].value;
        let OTC = document.getElementsByName("OTC")[0].value;
        let Advance = document.getElementsByName("Advance")[0].value;
        let Total = +OTC +MRC*Advance;
        document.getElementsByName("Total")[0].value = Total;
    }
</script>


@include('layouts.footer')

</body>

</html>