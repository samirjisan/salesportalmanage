<html>

<head>
    <title>Show All Sales</title>
    @include('layouts.header')

    <style>
        table {
            width:100%;
        }
        table, th, td {
            border: 2px solid black;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        /*#td tr:nth-child(even) {*/
        /*background-color: blue;*/
        /*}*/
        /*#td tr:nth-child(odd) {*/
        /*background-color: greenyellow;*/
        /*}*/
        th {
            background-color: olive;
            color: white;
        }
        h1 {
            color: blueviolet;
            text-align: center;
            /*border: 3px solid green;*/

        }

        /*body{*/
            /*background-image: url("/image/bcg.jpg");*/
            /*background-repeat: no-repeat;*/
            /*background-size: cover;*/
        /*}*/




    </style>
</head>

<body>
@include('layouts.body')



<nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="#">ORBIT</a>
        </div>
        <ul class="nav navbar-nav">
            <li><a href="{{ route('admuse.list') }}"><span class="glyphicon glyphicon-Add New User"></span> Add New User</a></li>
            <li><a href="{{ route('admuse.show') }}"><span class="glyphicon glyphicon-Show All Entries"></span>Show All Entries</a></li>
            <li><a href="{{ route('admuse.exportIntoExcel') }}"><span class="glyphicon glyphicon-Report"></span> Download Report</a></li>
            <li><a href="{{ route('user.see') }}"><span class="glyphicon glyphicon-Show All User"></span>Show All User</a></li>
            {{--<li><a href="{{ route('sales.exportIntoExcel') }}"><input type="submit" name="submit" value="Report"></a></li>--}}
            {{--<li><a href="#"><span class="glyphicon glyphicon-Add New User"></span> Login</a></li>--}}
        </ul>
        <ul class="nav navbar-nav navbar-right">
            <li><a href="{{ route('admin.logout') }}">( {{ App\Admin::find(Auth::guard('admin')->id())->email }} )<span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
            {{--<li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>--}}
        </ul>

        <form class="navbar-form navbar-left" >
            <div class="input-group" type="get" action="#">
                <input type="search" value="" class="form-control" placeholder="Search" name="query">
                <div class="input-group-btn">
                    <button class="btn btn-default" type="submit">
                        <i class="glyphicon glyphicon-search"></i>
                    </button>
                </div>

            </div>
        </form>
    </div>

</nav>


<h1>Show All Sale</h1>

@if(session('updateSuccess'))
<p style="color:green;">{{ session('updateSuccess') }}</p>
@endif

@if(session('deleteSuccess'))
    <p style="color:red;">{{ session('deleteSuccess') }}</p>
@endif


@if(session('addSuccess'))
    <p style="color:blue;">{{ session('addSuccess') }}</p>
@endif

<table border="1px">
    <tr style="color: #000088">
        {{--<th>Count</th>--}}
        <th>Create Date</th>
        <th>Zone</th>
        <th>Team</th>
        <th>Employee</th>
        <th>Subscriber ID</th>
        <th>Offer</th>
        <th>Package</th>
        <th>MRC</th>
        <th>OTC</th>
        <th>Advance</th>
        <th>Total</th>
        <th>Payment Date</th>
        <th>Action</th>
    </tr>
    @foreach($sales as $sale)
    <tr>
        <td>{{ $sale->Create }}</td>
        <td>{{ $sale->ZONE}}</td>
        <td>{{ $sale->TEAM }}</td>
        <td>{{ $sale->EMPLOYEE }}</td>
        <td>{{ $sale->Subscriber_ID }}</td>
        <td>{{ $sale->Offer }}</td>
        <td>{{ $sale->Package }}</td>
        <td>{{ $sale->MRC }}</td>
        <td>{{ $sale->OTC }}</td>
        <td>{{ $sale->Advance }}</td>
        <td>{{ $sale->Total }}</td>
        <td>{{ $sale->Delivery }}</td>

        {{--<td><a href="{{ route('admuse.edit',[$sale->Count]) }}" title="edit" class="edit" onclick="return confirm('Are you sure you want to edit this item')">Edit</a>||<a href="{{ route('admuse.delete',[$sale->Count]) }}"title="delete" class="delete" onclick="return confirm('Are you sure you want to delete this item')">Delete</a></td>--}}
        {{--<input type="submit" class="btnRegister"  value="Save"/>--}}
        <td><a href="{{ route('admuse.edit',[$sale->Count]) }}" title="edit" class="btnRegister1" onclick="return confirm('Are you sure you want to edit this item')">Edit</a>||<a href="{{ route('admuse.delete',[$sale->Count]) }}"title="delete" class="btnRegister2" onclick="return confirm('Are you sure you want to delete this item')">Delete</a></td>
    </tr>
    @endforeach
</table>

<span>
    {{$sales->links()}}
</span>

@include('layouts.footer')

</body>

</html>
