<?php

namespace App\Http\Controllers;


use App\Sale;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class UserController extends Controller
{


    public function index()
    {

        return view('sales.list');
    }

    public function register()
    {

        $this->validate(request(),[
            'Create' => 'required',
            'ZONE' => 'required',
            'TEAM' => 'required',
            'EMPLOYEE' => 'required',
            'Subscriber_ID' => 'required',
            'Offer' => 'required',
            'Package' => 'required',
            'MRC' => 'required',
            'OTC' => 'required',
            'Advance' => 'required',
            'Total' => 'required',
            'Delivery' => 'required'
        ]);

//        Sale::find(Auth::id())->sales()->create([

        Sale::create([
            'Create' => request('Create'),
            'ZONE' => request('ZONE'),
            'TEAM' => request('TEAM'),
            'EMPLOYEE' => request('EMPLOYEE'),
            'Subscriber_ID' => request('Subscriber_ID'),
            'Offer' => request('Offer'),
            'Package' => request('Package'),
            'MRC' => request('MRC'),
            'OTC' => request('OTC'),
            'Advance' => request('Advance'),
            'Total' => request('Total'),
            'Delivery' => request('Delivery')

        ]);

//        return 'registered';
        return redirect()->route('sales.show')->with('addSuccess','User Add Successful!');

//        return request()->all();

//        return "go die";

    }

//    public function showSale(){
//        return view('sales.show',compact('sales'));
//    }

}
