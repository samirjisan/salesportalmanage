<?php

namespace App\Http\Controllers;

use App\Sale;
use Illuminate\Http\Request;

class AdminManageController extends Controller
{
    public function index()
    {

        return view('admuse.list');
    }

    public function register()
    {

        $this->validate(request(),[
            'Create' => 'required',
            'ZONE' => 'required',
            'TEAM' => 'required',
            'EMPLOYEE' => 'required',
            'Subscriber_ID' => 'required',
            'Offer' => 'required',
            'Package' => 'required',
            'MRC' => 'required',
            'OTC' => 'required',
            'Advance' => 'required',
            'Total' => 'required',
            'Delivery' => 'required'
        ]);

        Sale::create([
            'Create' => request('Create'),
            'ZONE' => request('ZONE'),
            'TEAM' => request('TEAM'),
            'EMPLOYEE' => request('EMPLOYEE'),
            'Subscriber_ID' => request('Subscriber_ID'),
            'Offer' => request('Offer'),
            'Package' => request('Package'),
            'MRC' => request('MRC'),
            'OTC' => request('OTC'),
            'Advance' => request('Advance'),
            'Total' => request('Total'),
            'Delivery' => request('Delivery')

        ]);
        return redirect()->route('admuse.show')->with('addSuccess', 'User Add Successful!');
    }
}
